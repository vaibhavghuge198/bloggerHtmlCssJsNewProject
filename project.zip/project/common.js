// when click on sign up button, open sign up model

let signup=document.getElementById("signupModel");
function signupModel(){    
      signup.classList.add("open-popup");
}

function closePopup1(){
  signup.classList.remove("open-popup");
}







// when click on sign in button, open sign in model
var signin=document.getElementById("signinModel");
function signinModel(){
  signin.classList.add("open-popup2");  
}

function closePopup2(){
  signin.classList.remove("open-popup2");
  
}
