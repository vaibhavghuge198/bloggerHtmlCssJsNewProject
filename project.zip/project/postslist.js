// layer
var ovarlyr=document.getElementById("postlayer");
function ovrlye(){
  document.getElementById("postlayer").style.visibility='visible';
}
function closeOvrlyr(){
  document.getElementById("postlayer").style.visibility='hidden';

}


// delete post card model
var dltPost=document.getElementById("deleteModel");
function deletePosts(){
    document.getElementById("deleteModel").style.visibility='visible';
    document.getElementById("postlayer").style.visibility='visible';
}
function nobutton(){
    document.getElementById("deleteModel").style.visibility='hidden';
    document.getElementById("postlayer").style.visibility='hidden';
}
function yesbutton(){
    document.getElementsByClassName("third").style.visibility='hidden';
    document.getElementById("deleteModel").style.visibility='hidden';
    document.getElementById("postlayer").style.visibility='hidden';

}

// when click on tree dot  then you will got the next page
function post(){
    window.location="./post.html"

}