// var coment=document.getElementById("textarea1");
// function comment(){
//     if(coment===""){
//         document.write("comments #comments").write.inner=coment;

//     }
// }

// like increase

// var numCount = 0;
// var count = document.getElementsByClassName('.count');
// function addLike() {
//     numCount ++;
//     count.innerText = "numCount";
// }

function addLike(e){
    let count = Number(e.nextElementSibling.innerText) + 1;
    e.nextElementSibling.innerHTML = count;
  }

// //comment sectiponn
var coment=document.getElementById("textarea1");
function comment(){
document.getElementById("comments").innerHTML = "coment";
}

