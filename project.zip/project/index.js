
//sign up submmit data
function signUp() {
  
  if(document.getElementById("password2").value == document.getElementById("cfmpassword2").value) {
      var users = new Object();
      users.fullName = document.getElementById("fullName").value;
      users.username = document.getElementById("username").value;
      users.password2 = document.getElementById("password2").value;


      var postUser = new XMLHttpRequest(); // new HttpRequest instance to send user details

      postUser.open("POST", "/users", true); //Use the HTTP POST method to send data to server

      postUser.setRequestHeader("Content-Type", "application/json");

      // Convert the data in "users" object to JSON format before sending to the server.
      postUser.send(JSON.stringify(users));
  }
  else {
      alert("Password column and Confirm Password column doesn't match!")
  }
}

//sign in model

function signIn() {
  var enter_user=new Object();
  enter_user.username1=document.getElementById("username1");
  enter_user.password=document.getElementById("password");
}


//  when you  click on create -post btn  you will go to the create post model

var createNewPost=document.getElementById("createPost");
function createPosts(){
  createNewPost.classList.add("openPost");
}
function closePosts(){
  createNewPost.classList.remove("openPost");
}



//create new post
function createPos() {
  if (document.getElementById("input1").value && document.getElementById("textareaa").value) {    
      
  
  }
  else {
      document.getElementById("input1").ariaRequired;
  }
}
// when you  click on all-post btn  you will go to the all post page
function allPost(){
  window.location="./html/postslist.html"
}

//model ovarlayer
var ovarlyr=document.getElementById("overlayer");
function ovrlye(){
  document.getElementById("overlayer").style.visibility='visible';
}
function closeOvrlyr(){
  document.getElementById("overlayer").style.visibility='hidden';
}

// crete new post by clicking create button
let tital= document.getElementById("input1").value;
var post= document.getElementById("textareaa").value;
function create(){
  
  if(document.getElementById("input1").value && document.getElementById("textareaa").value ===""){    
      document.getElementById("headingTital").innerHTML = tital;
      document.getElementById("content_area").innerHTML = post;

  }
}

